
console.log('%cWithered foxy jumpscare v1.4','color:red;font-size:20px;font-weight:bold;');
console.log('loaded');
setInterval(function () {
    var r1 = Math.floor(Math.random()*10000)
    var r2 = Math.floor(Math.random()*10000)
    if(r1 == r2){
        jumpscare()
    }
}, 1000);

function jumpscare(){
    
var scare = new Audio(chrome.runtime.getURL('assets/folky.mp3'))     

var ifoxy = chrome.runtime.getURL("assets/forky.gif")
    scare.play()
    var jsc = document.createElement('div')

jsc.style.position = 'fixed'
jsc.style.top = '0'
jsc.style.left = '0'
jsc.style.width = '100vw'
jsc.style.height = '100vh'
jsc.style.zIndex = '999999'

var img = document.createElement('img')
img.src = ifoxy
img.style.width = '100%'
img.style.height = '100%'
img.style.objectFit = 'cover'

jsc.appendChild(img)
jsc.classList.add('jsc_foxy')

document.body.appendChild(jsc)

setTimeout(() => {
    document.body.removeChild(document.querySelector('.jsc_foxy'))
}, 700);
console.log("Did i scare you?");
}

